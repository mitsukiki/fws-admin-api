<?php
if (!defined('ABSPATH')) {
    exit;
}

/**
 * @var array $text_value テキストフィールドの値
 * @var string $radio_value ラジオボタンの値
 * @var int $image_value 画像IDの値
 * @var array $company_repeater_values 会社概要繰り返しフィールドの値
 */
?>

<div class="wrap">
    <h1>テーマ設定</h1>

    <form method="post" action="">
        <?php wp_nonce_field('save_custom_settings', 'custom_settings_nonce'); ?>
        <input type="hidden" id="active_tab_field" name="active_tab" value="">

        <div class="tab">
            <div class="tab-selecter-wrapper">

                <button type="button" class="tab-mobile-toggle" aria-label="メニューを開く">
                    <span class="hamburger-line"></span>
                    <span class="hamburger-line"></span>
                    <span class="hamburger-line"></span>
                </button>
                <div class="tab-selecter" data-target="content-base">
                    基本設定
                </div>
                <div class="tab-selecter" data-target="content-color">
                    カラー設定
                </div>
                <div class="tab-selecter" data-target="content-font">
                    フォント設定
                </div>
                <div class="tab-selecter" data-target="content-tag">
                    タグ設定
                </div>
                <div class="tab-selecter" data-target="content-sns-account">
                    SNSアカウント
                </div>
                <div class="tab-selecter" data-target="content-sns-profile">
                    SNSプロフィールリンク
                </div>
                <div class="tab-selecter" data-target="content-custom">
                    カスタムCSS・JS
                </div>
            </div>
            <div class="tab-content-wrapper">
                <div class="tab-content" data-content="content-base">
                    <div class="tab-content-box">
                        <h2 class="tab-content-box__tit">
                            ロゴ設定
                        </h2>
                        <div class="form-area">
                            <div class="form-row">
                                <label class="form-row__label">ヘッダーロゴ</label>
                                <div class="form-row__content form-img-upload">
                                    <input type="hidden" name="header_logo" id="header_logo_field"
                                        value="<?php echo esc_attr($header_logo_value); ?>">
                                    <div class="form-img-upload__preview-wrapper">
                                        <div class="form-img-upload__preview-device">
                                            <label class="form-img-upload__device-label">PC表示</label>
                                            <div id="header_logo_preview_pc"
                                                class="form-img-upload__preview form-img-upload__preview_pc">
                                                <?php if ($header_logo_value): ?>
                                                    <img
                                                        src="<?php echo esc_url(wp_get_attachment_url($header_logo_value)); ?>">
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                        <div class="form-img-upload__preview-device">
                                            <label class="form-img-upload__device-label">スマホ表示</label>
                                            <div id="header_logo_preview_sp"
                                                class="form-img-upload__preview form-img-upload__preview_sp">
                                                <?php if ($header_logo_value): ?>
                                                    <img
                                                        src="<?php echo esc_url(wp_get_attachment_url($header_logo_value)); ?>">
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-img-upload__btn-area">
                                        <button type="button" class="form-img-upload__btn button"
                                            id="header_logo_upload_button">
                                            画像を選択
                                        </button>
                                        <button type="button" class="form-img-upload__btn button"
                                            id="header_logo_remove_button">
                                            画像を削除
                                        </button>
                                    </div>
                                    <div class="form-img-upload__txt">
                                        <span class="form-img-upload__txt_red">※</span>表示サイズの2倍以上のサイズでのアップロードを推奨
                                    </div>
                                </div>
                            </div>

                            <div class="form-row">
                                <label class="form-row__label">ヘッダーロゴサイズ</label>
                                <div class="form-row__content form-range">
                                    <div class="form-range__row">
                                        <div class="form-range__col">
                                            <label class="form-range__col-label">PC</label>
                                            <div class="form-range__input-group">
                                                <input type="range" name="header_logo_width_pc"
                                                    value="<?php echo esc_attr(str_replace('px', '', $header_logo_width_pc)); ?>"
                                                    min="50" max="400" step="10" class="form-range__slider"
                                                    data-target="header_logo_width_pc_display">
                                                <span class="form-range__display" id="header_logo_width_pc_display">
                                                    <?php echo esc_html(str_replace('px', '', $header_logo_width_pc)); ?>px
                                                </span>
                                            </div>
                                        </div>
                                        <div class="form-range__col">
                                            <label class="form-range__col-label">スマホ</label>
                                            <div class="form-range__input-group">
                                                <input type="range" name="header_logo_width_sp"
                                                    value="<?php echo esc_attr(str_replace('px', '', $header_logo_width_sp)); ?>"
                                                    min="50" max="300" step="10" class="form-range__slider"
                                                    data-target="header_logo_width_sp_display">
                                                <span class="form-range__display" id="header_logo_width_sp_display">
                                                    <?php echo esc_html(str_replace('px', '', $header_logo_width_sp)); ?>px
                                                </span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="form-row">
                                <label class="form-row__label">フッターロゴ</label>
                                <div class="form-row__content form-img-upload">
                                    <input type="hidden" name="footer_logo" id="footer_logo_field"
                                        value="<?php echo esc_attr($footer_logo_value); ?>">
                                    <div class="form-img-upload__preview-wrapper">
                                        <div class="form-img-upload__preview-device">
                                            <label class="form-img-upload__device-label">PC表示</label>
                                            <div id="footer_logo_preview_pc"
                                                class="form-img-upload__preview form-img-upload__preview_pc">
                                                <?php if ($footer_logo_value): ?>
                                                    <img
                                                        src="<?php echo esc_url(wp_get_attachment_url($footer_logo_value)); ?>">
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                        <div class="form-img-upload__preview-device">
                                            <label class="form-img-upload__device-label">スマホ表示</label>
                                            <div id="footer_logo_preview_sp"
                                                class="form-img-upload__preview form-img-upload__preview_sp">
                                                <?php if ($footer_logo_value): ?>
                                                    <img
                                                        src="<?php echo esc_url(wp_get_attachment_url($footer_logo_value)); ?>">
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-img-upload__btn-area">
                                        <button type="button" class="form-img-upload__btn button"
                                            id="footer_logo_upload_button">
                                            画像を選択
                                        </button>
                                        <button type="button" class="form-img-upload__btn button"
                                            id="footer_logo_remove_button">
                                            画像を削除
                                        </button>
                                    </div>
                                    <div class="form-img-upload__txt">
                                        <span class="form-img-upload__txt_red">※</span>表示サイズの2倍以上のサイズでのアップロードを推奨
                                    </div>
                                </div>
                            </div>

                            <div class="form-row">
                                <label class="form-row__label">フッターロゴサイズ</label>
                                <div class="form-row__content form-range">
                                    <div class="form-range__row">
                                        <div class="form-range__col">
                                            <label class="form-range__col-label">PC</label>
                                            <div class="form-range__input-group">
                                                <input type="range" name="footer_logo_width_pc"
                                                    value="<?php echo esc_attr(str_replace('px', '', $footer_logo_width_pc)); ?>"
                                                    min="50" max="400" step="10" class="form-range__slider"
                                                    data-target="footer_logo_width_pc_display">
                                                <span class="form-range__display" id="footer_logo_width_pc_display">
                                                    <?php echo esc_html(str_replace('px', '', $footer_logo_width_pc)); ?>px
                                                </span>
                                            </div>
                                        </div>
                                        <div class="form-range__col">
                                            <label class="form-range__col-label">スマホ</label>
                                            <div class="form-range__input-group">
                                                <input type="range" name="footer_logo_width_sp"
                                                    value="<?php echo esc_attr(str_replace('px', '', $footer_logo_width_sp)); ?>"
                                                    min="50" max="300" step="10" class="form-range__slider"
                                                    data-target="footer_logo_width_sp_display">
                                                <span class="form-range__display" id="footer_logo_width_sp_display">
                                                    <?php echo esc_html(str_replace('px', '', $footer_logo_width_sp)); ?>px
                                                </span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>


                        </div>
                    </div>
                    <div class="tab-content-box">
                        <h2 class="tab-content-box__tit">
                            会社基本情報
                        </h2>
                        <div class="form-area">
                            <div class="form-row">
                                <label class="form-row__label">会社名・事業者名</label>
                                <div class="form-row__content form-text">
                                    <input type="text" id="company_name" name="company_name"
                                        value="<?php echo esc_attr($company_name); ?>" class="form-text__input"
                                        placeholder="ABC株式会社">
                                </div>
                            </div>
                            <div class="form-row">
                                <label class="form-row__label">電話番号</label>
                                <div class="form-row__content form-text">
                                    <input type="tel" id="company_tel" name="company_tel"
                                        value="<?php echo esc_attr($company_tel); ?>" class="form-text__input"
                                        placeholder="03-1234-5678">
                                </div>
                            </div>
                            <div class="form-row">
                                <label class="form-row__label">郵便番号</label>
                                <div class="form-row__content form-text">
                                    <input type="text" id="company_zip" name="company_zip"
                                        value="<?php echo esc_attr($company_zip); ?>"
                                        class="form-text__input form-text__input_small" placeholder="123-4567">
                                </div>
                            </div>
                            <div class="form-row">
                                <label class="form-row__label">住所</label>
                                <div class="form-row__content form-text">
                                    <input type="text" id="company_address" name="company_address"
                                        value="<?php echo esc_attr($company_address); ?>" class="form-text__input"
                                        placeholder="東京都渋谷区〇〇1-1-1">
                                    <div class="form-text__txt">建物名など</div>
                                    <input type="text" id="company_building" name="company_building"
                                        value="<?php echo esc_attr($company_building); ?>" class="form-text__input"
                                        placeholder="ABCビル3F　301">
                                </div>
                            </div>
                            <div class="form-row">
                                <label class="form-row__label">営業時間(受付時間)</label>
                                <div class="form-row__content form-text">
                                    <input type="text" id="company_opening" name="company_opening"
                                        value="<?php echo esc_attr($company_opening); ?>" class="form-text__input"
                                        placeholder="9:00～18:00">
                                </div>
                            </div>
                            <div class="form-row">
                                <label class="form-row__label">休業日</label>
                                <div class="form-row__content form-text">
                                    <input type="text" id="company_closed" name="company_closed"
                                        value="<?php echo esc_attr($company_closed); ?>" class="form-text__input"
                                        placeholder="土・日・祝日・年末年始・夏季">
                                </div>
                            </div>
                            <div class="form-row">
                                <label class="form-row__label">Google マップ</label>
                                <div class="form-row__content form-textarea">
                                    <textarea type="text" id="company_map" name="company_map"
                                        class="form-textarea__textarea"
                                        placeholder="<iframe src=“https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d6483.570832677746!2d139.6981736370628!3d35.657658150832816!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x60188b563b00109f%3A0x337328def1e2ab26!2sShibuya%20Station!5e0!3m2!1sen!2sjp!4v1615180134810!5m2!1sen!2sjp” width=“600” height=“450” style=“border:0;” allowfullscreen=“” loading=“lazy”></iframe>"><?php echo esc_html($company_map); ?></textarea>
                                </div>
                            </div>
                            <div class="form-row">
                                <label class="form-row__label">その他</label>
                                <div class="form-row__content form-repeater">
                                    <div id="repeater-fields" class="sortable-repeater">
                                        <?php
                                        if (!empty($company_repeater_values)) {
                                            foreach ($company_repeater_values as $index => $value) {
                                                // Handle both the new structure (array with title/text) and legacy structure (string)
                                                $title = is_array($value) && isset($value['title']) ? $value['title'] : '';
                                                $text = is_array($value) && isset($value['text']) ? $value['text'] : $value; // For backwards compatibility
                                                ?>
                                                <div class="repeater-row" data-index="<?php echo $index; ?>">
                                                    <div class="repeater-drag-handle">
                                                        <span class="dashicons dashicons-menu"></span>
                                                    </div>
                                                    <div class="repeater-row__inner">
                                                        <div class="repeater-field">
                                                            <label>タイトル</label>
                                                            <input type="text" name="company_repeater_title[]"
                                                                value="<?php echo esc_attr($title); ?>" class="repeater-input">
                                                        </div>
                                                        <div class="repeater-field">
                                                            <label>テキスト</label>
                                                            <?php
                                                            $editor_id = 'company_repeater_text_' . $index;
                                                            $settings = array(
                                                                'textarea_name' => 'company_repeater_text[]',
                                                                'media_buttons' => true,
                                                                'textarea_rows' => 5,
                                                                'editor_class' => 'wp-editor-area',
                                                                'tinymce' => array(
                                                                    'allow_html_in_named_anchor' => true,
                                                                    'verify_html' => false,
                                                                    'valid_elements' => '*[*]',
                                                                    'extended_valid_elements' => 'span[*],iframe[*],strong[*],br[*]',
                                                                    'paste_as_text' => false,
                                                                    'paste_retain_style_properties' => 'all',
                                                                    'paste_word_valid_elements' => '*[*]'
                                                                ),
                                                                'quicktags' => true,
                                                            );
                                                            wp_editor($text, $editor_id, $settings);
                                                            ?>
                                                        </div>
                                                    </div>
                                                    <button type="button" class="remove-row button">削除</button>
                                                </div>
                                                <?php
                                            }
                                        }
                                        ?>
                                    </div>
                                    <button type="button" id="add-row"
                                        class="button repeater-add-button">フィールドを追加</button>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="tab-content-box">
                        <h2 class="tab-content-box__tit">
                            その他
                        </h2>
                        <div class="form-area">
                            <div class="form-row">
                                <label class="form-row__label">copyright(サイトクレジット)表記設定</label>
                                <div class="form-row__content form-text">
                                    <input type="text" id="copyright_text" name="copyright_text"
                                        value="<?php echo esc_attr($copyright_text); ?>" class="form-text__input"
                                        placeholder="© 2024 Your Company Name. All rights reserved.">
                                </div>
                            </div>
                            <div class="form-row">
                                <label class="form-row__label">NO IMAGE画像</label>
                                <div class="form-row__content form-img-upload">
                                    <input type="hidden" name="no_image" id="no_image_field"
                                        value="<?php echo esc_attr($no_image_value); ?>">
                                    <div id="no_image_preview" class="form-img-upload__preview">
                                        <?php if ($no_image_value): ?>
                                            <img src="<?php echo esc_url(wp_get_attachment_url($no_image_value)); ?>">
                                        <?php endif; ?>
                                    </div>
                                    <div class="form-img-upload__btn-area">
                                        <button type="button" class="form-img-upload__btn button"
                                            id="no_image_upload_button">
                                            画像を選択
                                        </button>
                                        <button type="button" class="form-img-upload__btn button"
                                            id="no_image_remove_button">
                                            画像を削除
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="tab-content" data-content="content-color">
                    <div class="tab-content-box">
                        <h2 class="tab-content-box__tit">
                            基本カラー設定
                        </h2>
                        <div class="form-area">
                            <div class="form-row">
                                <label class="form-row__label form-row__label_pt-small">ベースカラー</label>
                                <div class="form-row__content form-color-picker">
                                    <input type="text" name="base_color" class="add-color-picker-number-field"
                                        value="<?php echo esc_attr($base_color); ?>">
                                </div>
                            </div>
                            <div class="form-row">
                                <label class="form-row__label form-row__label_pt-small">テキストカラー</label>
                                <div class="form-row__content form-color-picker">
                                    <input type="text" name="contrast_color" class="add-color-picker-number-field"
                                        value="<?php echo esc_attr($contrast_color); ?>">
                                </div>
                            </div>
                            <div class="form-row">
                                <label class="form-row__label form-row__label_pt-small">メインカラー</label>
                                <div class="form-row__content form-color-picker">
                                    <input type="text" name="main_color" class="add-color-picker-number-field"
                                        value="<?php echo esc_attr($main_color); ?>">
                                </div>
                            </div>
                            <div class="form-row">
                                <label class="form-row__label form-row__label_pt-small">アクセントカラー</label>
                                <div class="form-row__content form-color-picker">
                                    <input type="text" name="accent_color" class="add-color-picker-number-field"
                                        value="<?php echo esc_attr($accent_color); ?>">
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="tab-content-box">
                        <h2 class="tab-content-box__tit">
                            カスタム配色設定
                        </h2>
                        <div class="form-area">
                            <div class="form-row">
                                <label class="form-row__label form-row__label_pt-small">テキストカラー1</label>
                                <div class="form-row__content form-color-picker">
                                    <input type="text" name="primary_contrast_color"
                                        class="add-color-picker-number-field"
                                        value="<?php echo esc_attr($primary_contrast_color); ?>">
                                </div>
                                <label class="form-row__label form-row__label_pt-small">背景カラー1</label>
                                <div class="form-row__content form-color-picker">
                                    <input type="text" name="primary_color" class="add-color-picker-number-field"
                                        value="<?php echo esc_attr($primary_color); ?>">
                                </div>
                            </div>
                            <div class="form-row">
                                <label class="form-row__label form-row__label_pt-small">テキストカラー2</label>
                                <div class="form-row__content form-color-picker">
                                    <input type="text" name="secondary_contrast_color"
                                        class="add-color-picker-number-field"
                                        value="<?php echo esc_attr($secondary_contrast_color); ?>">
                                </div>
                                <label class="form-row__label form-row__label_pt-small">背景カラー2</label>
                                <div class="form-row__content form-color-picker">
                                    <input type="text" name="secondary_color" class="add-color-picker-number-field"
                                        value="<?php echo esc_attr($secondary_color); ?>">
                                </div>
                            </div>
                            <div class="form-row">
                                <label class="form-row__label form-row__label_pt-small">テキストカラー3</label>
                                <div class="form-row__content form-color-picker">
                                    <input type="text" name="tertiary_contrast_color"
                                        class="add-color-picker-number-field"
                                        value="<?php echo esc_attr($tertiary_contrast_color); ?>">
                                </div>
                                <label class="form-row__label form-row__label_pt-small">背景カラー3</label>
                                <div class="form-row__content form-color-picker">
                                    <input type="text" name="tertiary_color" class="add-color-picker-number-field"
                                        value="<?php echo esc_attr($tertiary_color); ?>">
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="tab-content-box">
                        <h2 class="tab-content-box__tit">
                            ボタン配色設定
                        </h2>
                        <div class="form-area">
                            <div class="form-row">
                                <label class="form-row__label form-row__label_pt-small">ボタンカラー1</label>
                                <div class="form-row__content form-color-picker">
                                    <input type="text" name="button_color_1" class="add-color-picker-number-field"
                                        value="<?php echo esc_attr($button_color_1); ?>">
                                </div>
                                <label class="form-row__label form-row__label_pt-small">ボタンテキストカラー1</label>
                                <div class="form-row__content form-color-picker">
                                    <input type="text" name="button_text_color_1" class="add-color-picker-number-field"
                                        value="<?php echo esc_attr($button_text_color_1); ?>">
                                </div>
                            </div>
                            <div class="form-row">
                                <label class="form-row__label form-row__label_pt-small">ボタンカラー2</label>
                                <div class="form-row__content form-color-picker">
                                    <input type="text" name="button_color_2" class="add-color-picker-number-field"
                                        value="<?php echo esc_attr($button_color_2); ?>">
                                </div>
                                <label class="form-row__label form-row__label_pt-small">ボタンテキストカラー2</label>
                                <div class="form-row__content form-color-picker">
                                    <input type="text" name="button_text_color_2" class="add-color-picker-number-field"
                                        value="<?php echo esc_attr($button_text_color_2); ?>">
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="tab-content-box">
                        <h2 class="tab-content-box__tit">
                            枠線設定
                        </h2>
                        <div class="form-area">
                            <div class="form-row">
                                <label class="form-row__label form-row__label_pt-small">ボーダーカラー1</label>
                                <div class="form-row__content form-color-picker">
                                    <input type="text" name="base_border_color" class="add-color-picker-number-field"
                                        value="<?php echo esc_attr($base_border_color); ?>">
                                </div>
                                <label class="form-row__label form-row__label_pt-small">ボーダーカラー2</label>
                                <div class="form-row__content form-color-picker">
                                    <input type="text" name="border_color_2" class="add-color-picker-number-field"
                                        value="<?php echo esc_attr($border_color_2); ?>">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="tab-content" data-content="content-font">
                    <div class="tab-content-box">
                        <h2 class="tab-content-box__tit">
                            フォント設定　
                        </h2>
                        <div class="form-area">
                            <div class="form-row">
                                <label class="form-row__label">モード選択</label>
                                <div class="form-row__content form-radio">
                                    <label class="form-radio__label">
                                        <input type="radio" name="font_mode" value="normal" <?php echo (empty($font_mode) || $font_mode === 'normal') ? 'checked' : ''; ?> class="form-radio__input">
                                        <span class="form-radio__text">ノーマル</span>
                                    </label>
                                    <label class="form-radio__label">
                                        <input type="radio" name="font_mode" value="custom" <?php echo ($font_mode === 'custom') ? 'checked' : ''; ?> class="form-radio__input">
                                        <span class="form-radio__text">カスタム</span>
                                    </label>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="tab-content-box font-mode-normal" <?php echo ($font_mode === 'custom') ? 'style="display:none;"' : ''; ?>>
                        <h2 class="tab-content-box__tit">
                            ノーマルフォント設定
                        </h2>
                        <div class="form-area">
                            <div class="form-row">
                                <label class="form-row__label">基本フォント</label>
                                <div class="form-row__content form-google-font">
                                    <select name="google_font_base" id="google_font_base" class="google-font-selector">
                                        <option value="">デフォルトフォント</option>
                                        <option value="Noto Sans JP" <?php echo ($google_font_base === 'Noto Sans JP') ? 'selected' : ''; ?>>Noto Sans JP</option>
                                        <option value="Sawarabi Gothic" <?php echo ($google_font_base === 'Sawarabi Gothic') ? 'selected' : ''; ?>>Sawarabi Gothic</option>
                                        <option value="M PLUS 1p" <?php echo ($google_font_base === 'M PLUS 1p') ? 'selected' : ''; ?>>M PLUS 1p</option>
                                        <option value="Kosugi Maru" <?php echo ($google_font_base === 'Kosugi Maru') ? 'selected' : ''; ?>>Kosugi Maru</option>
                                        <option value="Zen Kaku Gothic New" <?php echo ($google_font_base === 'Zen Kaku Gothic New') ? 'selected' : ''; ?>>Zen Kaku Gothic New</option>
                                        <option value="Zen Maru Gothic" <?php echo ($google_font_base === 'Zen Maru Gothic') ? 'selected' : ''; ?>>Zen Maru Gothic</option>
                                        <option value="Shippori Mincho" <?php echo ($google_font_base === 'Shippori Mincho') ? 'selected' : ''; ?>>Shippori Mincho</option>
                                        <option value="Roboto" <?php echo ($google_font_base === 'Roboto') ? 'selected' : ''; ?>>Roboto</option>
                                        <option value="Open Sans" <?php echo ($google_font_base === 'Open Sans') ? 'selected' : ''; ?>>Open Sans</option>
                                        <option value="Lato" <?php echo ($google_font_base === 'Lato') ? 'selected' : ''; ?>>Lato</option>
                                    </select>
                                    <div class="google-font-preview" id="google_font_base_preview">
                                        プレビューテキスト：これはサンプルテキストです。Sample Text 123
                                    </div>
                                </div>
                            </div>
                            <div class="form-row">
                                <label class="form-row__label">英語フォント</label>
                                <div class="form-row__content form-google-font">
                                    <select name="google_font_en" id="google_font_en" class="google-font-selector">
                                        <option value="">基本フォントと同じ</option>
                                        <option value="Playfair Display" <?php echo ($google_font_en === 'Playfair Display') ? 'selected' : ''; ?>>Playfair Display</option>
                                        <option value="Montserrat" <?php echo ($google_font_en === 'Montserrat') ? 'selected' : ''; ?>>Montserrat</option>
                                        <option value="Oswald" <?php echo ($google_font_en === 'Oswald') ? 'selected' : ''; ?>>Oswald</option>
                                        <option value="Roboto" <?php echo ($google_font_en === 'Roboto') ? 'selected' : ''; ?>>Roboto</option>
                                        <option value="Open Sans" <?php echo ($google_font_en === 'Open Sans') ? 'selected' : ''; ?>>Open Sans</option>
                                        <option value="Lato" <?php echo ($google_font_en === 'Lato') ? 'selected' : ''; ?>>Lato</option>
                                        <option value="Poppins" <?php echo ($google_font_en === 'Poppins') ? 'selected' : ''; ?>>Poppins</option>
                                        <option value="Inter" <?php echo ($google_font_en === 'Inter') ? 'selected' : ''; ?>>Inter</option>
                                        <option value="Source Sans Pro" <?php echo ($google_font_en === 'Source Sans Pro') ? 'selected' : ''; ?>>Source Sans Pro</option>
                                        <option value="Raleway" <?php echo ($google_font_en === 'Raleway') ? 'selected' : ''; ?>>Raleway</option>
                                        <option value="Nunito" <?php echo ($google_font_en === 'Nunito') ? 'selected' : ''; ?>>Nunito</option>
                                        <option value="Work Sans" <?php echo ($google_font_en === 'Work Sans') ? 'selected' : ''; ?>>Work Sans</option>
                                    </select>
                                    <div class="google-font-preview" id="google_font_en_preview">
                                        <h3>en Preview: Sample en Text</h3>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="tab-content-box font-mode-custom" <?php echo ($font_mode !== 'custom') ? 'style="display:none;"' : ''; ?>>
                        <h2 class="tab-content-box__tit">
                            カスタムフォント設定
                        </h2>
                        <div class="form-area">
                            <div class="form-row">
                                <label class="form-row__label">Google Font linkタグ</label>
                                <div class="form-row__content form-textarea">
                                    <textarea name="custom_google_font_link" class="form-textarea__textarea" rows="3" placeholder='<link href="https://fonts.googleapis.com/css2?family=Noto+Sans+JP:wght@400;700&display=swap" rel="stylesheet">'><?php echo esc_textarea(stripslashes($custom_google_font_link)); ?></textarea>
                                    <p class="description">Google Fontsから取得したlinkタグを貼り付けてください</p>
                                </div>
                            </div>
                            <div class="form-row">
                                <label class="form-row__label">Adobe Font linkタグ</label>
                                <div class="form-row__content form-textarea">
                                    <textarea name="custom_adobe_font_link" class="form-textarea__textarea" rows="3" placeholder='<link rel="stylesheet" href="https://use.typekit.net/xxxxxx.css">'><?php echo esc_textarea(stripslashes($custom_adobe_font_link)); ?></textarea>
                                    <p class="description">Adobe Fontsから取得したlinkタグを貼り付けてください</p>
                                </div>
                            </div>
                            <div class="form-row">
                                <label class="form-row__label">基本フォント</label>
                                <div class="form-row__content form-text">
                                    <input type="text" name="custom_font_base" value="<?php echo esc_attr(stripslashes($custom_font_base)); ?>" class="form-text__input" placeholder='"Noto Sans JP", sans-serif'>
                                    <p class="description">CSS変数 --base-font-family に適用されます</p>
                                </div>
                            </div>
                            <div class="form-row">
                                <label class="form-row__label">英語フォント</label>
                                <div class="form-row__content form-text">
                                    <input type="text" name="custom_font_en" value="<?php echo esc_attr(stripslashes($custom_font_en)); ?>" class="form-text__input" placeholder='"Open Sans", sans-serif'>
                                    <p class="description">CSS変数 --en-font-family に適用されます</p>
                                </div>
                            </div>
                            <div class="form-row">
                                <label class="form-row__label">その他フォント1</label>
                                <div class="form-row__content form-text">
                                    <input type="text" name="custom_font_other1" value="<?php echo esc_attr(stripslashes($custom_font_other1)); ?>" class="form-text__input" placeholder='"Roboto", sans-serif'>
                                    <p class="description">CSS変数 --other-font-family-1 に適用されます</p>
                                </div>
                            </div>
                            <div class="form-row">
                                <label class="form-row__label">その他フォント2</label>
                                <div class="form-row__content form-text">
                                    <input type="text" name="custom_font_other2" value="<?php echo esc_attr(stripslashes($custom_font_other2)); ?>" class="form-text__input" placeholder='"Roboto", serif'>
                                    <p class="description">CSS変数 --other-font-family-2 に適用されます</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="tab-content" data-content="content-tag">
                    <div class="tab-content-box">
                        <h2 class="tab-content-box__tit">
                            タグマネージャー設定
                        </h2>
                        <div class="form-area">
                            <div class="form-row">
                                <label class="form-row__label">&lt;head&gt;用コード</label>
                                <div class="form-row__content">
                                    <textarea name="gtm_head_code" rows="10"
                                        class="large-text code"><?php echo esc_textarea(stripslashes_deep($gtm_head_code)); ?></textarea>
                                    <p class="description">Googleタグマネージャーから提供される&lt;head&gt;タグ内に配置するコードを貼り付けてください</p>
                                </div>
                            </div>

                            <div class="form-row">
                                <label class="form-row__label">&lt;body&gt;用コード</label>
                                <div class="form-row__content">
                                    <textarea name="gtm_body_code" rows="10"
                                        class="large-text code"><?php echo esc_textarea(stripslashes_deep($gtm_body_code)); ?></textarea>
                                    <p class="description">Googleタグマネージャーから提供される&lt;body&gt;タグの直後に配置するコードを貼り付けてください</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="tab-content-box">
                        <h2 class="tab-content-box__tit">
                            その他解析タグ
                        </h2>
                        <div class="form-area">
                            <div class="form-row">
                                <label class="form-row__label">アクセス解析タグ（ヘッダー用）</label>
                                <div class="form-row__content">
                                    <textarea name="analytics_head_code" rows="10"
                                        class="large-text code"><?php echo esc_textarea(stripslashes_deep($analytics_head_code)); ?></textarea>
                                    <p class="description">その他の解析ツールのヘッダー用コードを貼り付けてください。&lt;head&gt;タグ内に出力されます。</p>
                                </div>
                            </div>
                            <div class="form-row">
                                <label class="form-row__label">アクセス解析タグ（フッター用）</label>
                                <div class="form-row__content">
                                    <textarea name="analytics_footer_code" rows="10"
                                        class="large-text code"><?php echo esc_textarea(stripslashes_deep($analytics_footer_code)); ?></textarea>
                                    <p class="description">その他の解析ツールのフッター用コードを貼り付けてください。&lt;/body&gt;タグの直前に出力されます。</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="tab-content" data-content="content-sns-account">
                    <div class="tab-content-box">
                        <h2 class="tab-content-box__tit">
                            SNSアカウント
                        </h2>
                        <div class="form-area">
                            <div class="form-row">
                                <label class="form-row__label">Instagram</label>
                                <div class="form-row__content form-text">
                                    <input type="url" id="instagram_url" name="instagram_url"
                                        value="<?php echo esc_attr($instagram_url); ?>" class="form-text__input"
                                        placeholder="https://www.instagram.com/youraccount">
                                </div>
                            </div>
                            <div class="form-row">
                                <label class="form-row__label">LINE</label>
                                <div class="form-row__content form-text">
                                    <input type="url" id="line_url" name="line_url"
                                        value="<?php echo esc_attr($line_url); ?>" class="form-text__input"
                                        placeholder="https://line.me/ti/p/yourlineid">
                                </div>
                            </div>
                            <div class="form-row">
                                <label class="form-row__label">X (Twitter)</label>
                                <div class="form-row__content form-text">
                                    <input type="url" id="twitter_url" name="twitter_url"
                                        value="<?php echo esc_attr($twitter_url); ?>" class="form-text__input"
                                        placeholder="https://x.com/youraccount">
                                </div>
                            </div>
                            <div class="form-row">
                                <label class="form-row__label">Facebook</label>
                                <div class="form-row__content form-text">
                                    <input type="url" id="facebook_url" name="facebook_url"
                                        value="<?php echo esc_attr($facebook_url); ?>" class="form-text__input"
                                        placeholder="https://www.facebook.com/yourpage">
                                </div>
                            </div>
                            <div class="form-row">
                                <label class="form-row__label">YouTube</label>
                                <div class="form-row__content form-text">
                                    <input type="url" id="youtube_url" name="youtube_url"
                                        value="<?php echo esc_attr($youtube_url); ?>" class="form-text__input"
                                        placeholder="https://www.youtube.com/channel/yourchannel">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="tab-content" data-content="content-sns-profile">
                    <div class="tab-content-box">
                        <h2 class="tab-content-box__tit">
                            SNSプロフィールリンクページ
                        </h2>
                        <div class="form-area">
                            <div class="form-row">
                                <label class="form-row__label">背景画像</label>
                                <div class="form-row__content form-img-upload">
                                    <input type="hidden" name="sns_bg_image" id="sns_bg_image_field"
                                        value="<?php echo esc_attr($sns_bg_image_value); ?>">
                                    <div id="sns_bg_image_preview" class="form-img-upload__preview">
                                        <?php if ($sns_bg_image_value): ?>
                                            <img src="<?php echo esc_url(wp_get_attachment_url($sns_bg_image_value)); ?>">
                                        <?php endif; ?>
                                    </div>
                                    <div class="form-img-upload__btn-area">
                                        <button type="button" class="form-img-upload__btn button"
                                            id="sns_bg_image_upload_button">
                                            画像を選択
                                        </button>
                                        <button type="button" class="form-img-upload__btn button"
                                            id="sns_bg_image_remove_button">
                                            画像を削除
                                        </button>
                                    </div>
                                </div>
                            </div>

                            <div class="form-row">
                                <label class="form-row__label">アイコン画像</label>
                                <div class="form-row__content form-img-upload">
                                    <input type="hidden" name="sns_icon" id="sns_icon_field"
                                        value="<?php echo esc_attr($sns_icon_value); ?>">
                                    <div id="sns_icon_preview" class="form-img-upload__preview">
                                        <?php if ($sns_icon_value): ?>
                                            <img src="<?php echo esc_url(wp_get_attachment_url($sns_icon_value)); ?>">
                                        <?php endif; ?>
                                    </div>
                                    <div class="form-img-upload__btn-area">
                                        <button type="button" class="form-img-upload__btn button"
                                            id="sns_icon_upload_button">
                                            画像を選択
                                        </button>
                                        <button type="button" class="form-img-upload__btn button"
                                            id="sns_icon_remove_button">
                                            画像を削除
                                        </button>
                                    </div>
                                </div>
                            </div>

                            <div class="form-row">
                                <label class="form-row__label">名前</label>
                                <div class="form-row__content form-text">
                                    <input type="text" id="sns_name" name="sns_name"
                                        value="<?php echo esc_attr($sns_name); ?>" class="form-text__input"
                                        placeholder="Growth Hive">
                                </div>
                            </div>

                            <div class="form-row">
                                <label class="form-row__label">ポスト</label>
                                <div class="form-row__content form-text">
                                    <input type="text" id="sns_post" name="sns_post"
                                        value="<?php echo esc_attr($sns_post); ?>" class="form-text__input"
                                        placeholder="Digital Marketing Agency">
                                </div>
                            </div>

                            <div class="form-row">
                                <label class="form-row__label">概要説明文</label>
                                <div class="form-row__content form-textarea">
                                    <textarea id="sns_description" name="sns_description"
                                        class="form-textarea__textarea"
                                        placeholder="データに基づく深い洞察と先進的なマーケティング戦略で、クライアントの成功をリードし、持続的な成長を支援します。"><?php echo esc_textarea($sns_description); ?></textarea>
                                </div>
                            </div>

                            <div class="form-row">
                                <label class="form-row__label">SNSリピーター</label>
                                <div class="form-row__content form-repeater">
                                    <div id="sns-repeater-fields" class="sortable-repeater">
                                        <?php
                                        if (!empty($sns_repeater_values)) {
                                            foreach ($sns_repeater_values as $index => $value) {
                                                $icon_id = isset($value['icon_id']) ? $value['icon_id'] : '';
                                                $title = isset($value['title']) ? $value['title'] : '';
                                                $url = isset($value['url']) ? $value['url'] : '';
                                                ?>
                                                <div class="repeater-row" data-index="<?php echo $index; ?>">
                                                    <div class="repeater-drag-handle">
                                                        <span class="dashicons dashicons-menu"></span>
                                                    </div>
                                                    <div class="repeater-row__inner">
                                                        <div class="repeater-field">
                                                            <label>アイコン</label>
                                                            <div class="form-img-upload form-img-upload_small">
                                                                <input type="hidden" name="sns_repeater_icon[]"
                                                                    value="<?php echo esc_attr($icon_id); ?>"
                                                                    class="sns-icon-field">
                                                                <div class="form-img-upload__preview sns-icon-preview">
                                                                    <?php if ($icon_id): ?>
                                                                        <img
                                                                            src="<?php echo esc_url(wp_get_attachment_url($icon_id)); ?>">
                                                                    <?php endif; ?>
                                                                </div>
                                                                <div class="form-img-upload__btn-area">
                                                                    <button type="button"
                                                                        class="form-img-upload__btn button sns-icon-upload">
                                                                        選択
                                                                    </button>
                                                                    <button type="button"
                                                                        class="form-img-upload__btn button sns-icon-remove">
                                                                        削除
                                                                    </button>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="repeater-field">
                                                            <label>タイトル</label>
                                                            <input type="text" name="sns_repeater_title[]"
                                                                value="<?php echo esc_attr($title); ?>" class="repeater-input">
                                                        </div>
                                                        <div class="repeater-field">
                                                            <label>リンク先URL</label>
                                                            <input type="url" name="sns_repeater_url[]"
                                                                value="<?php echo esc_attr($url); ?>" class="repeater-input">
                                                        </div>
                                                    </div>
                                                    <button type="button" class="remove-row button">削除</button>
                                                </div>
                                                <?php
                                            }
                                        }
                                        ?>
                                    </div>
                                    <button type="button" id="add-sns-row"
                                        class="button repeater-add-button">SNSリンクを追加</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="tab-content" data-content="content-custom">
                    <div class="tab-content-box">
                        <h2 class="tab-content-box__tit">
                            カスタム設定
                        </h2>
                        <div class="form-area">
                            <div class="form-row">
                                <label class="form-row__label">カスタムCSS</label>
                                <div class="form-row__content">
                                    <textarea name="custom_css" rows="15"
                                        class="large-text code"><?php echo esc_textarea($custom_css); ?></textarea>
                                    <p class="description">フロントエンドに出力されるカスタムCSSを記述してください。&lt;style&gt;タグは不要です。</p>
                                </div>
                            </div>

                            <div class="form-row">
                                <label class="form-row__label">カスタムJavaScript</label>
                                <div class="form-row__content">
                                    <textarea name="custom_js" rows="15"
                                        class="large-text code"><?php echo esc_textarea($custom_js); ?></textarea>
                                    <p class="description">フロントエンドに出力されるカスタムJavaScriptを記述してください。&lt;script&gt;タグは不要です。
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="custom-settings-container">
            <?php submit_button('設定を保存'); ?>
        </div>
    </form>
</div>