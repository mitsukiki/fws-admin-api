<?php

if (!defined('ABSPATH')) {
    exit;
}

class CustomSettingsAdminInterface
{
    private $validator;
    private $database;
    private $errors = array();
    private $messages = array();

    public function __construct(CustomSettingsValidator $validator, CustomSettingsDatabase $database)
    {
        $this->validator = $validator;
        $this->database = $database;
        
        add_action('admin_menu', array($this, 'add_menu_page'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_scripts'));
        add_action('admin_notices', array($this, 'display_messages'));
        add_action('admin_init', array($this, 'handle_form_submission'));
    }

    public function add_menu_page()
    {
        add_menu_page(
            'テーマ設定',
            'テーマ設定',
            'manage_options',
            'custom-settings',
            array($this, 'render_settings_page'),
            'dashicons-admin-generic',
            99
        );
    }

    public function enqueue_scripts($hook)
    {
        if ($hook !== 'toplevel_page_custom-settings') {
            return;
        }

        wp_enqueue_media();
        wp_enqueue_editor();
        wp_enqueue_script('jquery-ui-sortable');

        if (defined('WP_ENV') && WP_ENV === 'development') {
            wp_register_script('vite-client', 'http://localhost:3000/@vite/client', [], null);
            wp_register_script('custom-settings-js', 'http://localhost:3000/js/custom-settings.js', ['jquery'], null, true);

            add_filter('script_loader_tag', function ($tag, $handle) {
                if (in_array($handle, ['vite-client', 'custom-settings-js'])) {
                    return str_replace('<script ', '<script type="module" ', $tag);
                }
                return $tag;
            }, 10, 2);

            wp_enqueue_script('vite-client');
            wp_enqueue_script('custom-settings-js');
        } else {
            $manifest_path = plugin_dir_path(dirname(__FILE__)) . 'dist/manifest.json';
            if (file_exists($manifest_path)) {
                $manifest = json_decode(file_get_contents($manifest_path), true);

                if (isset($manifest['js/custom-settings.js'])) {
                    if (isset($manifest['js/custom-settings.js']['css'][0])) {
                        wp_enqueue_style(
                            'custom-settings-style',
                            plugins_url('dist/' . $manifest['js/custom-settings.js']['css'][0], dirname(__FILE__))
                        );
                    }

                    wp_enqueue_script(
                        'custom-settings-js',
                        plugins_url('dist/' . $manifest['js/custom-settings.js']['file'], dirname(__FILE__)),
                        array('jquery'),
                        null,
                        true
                    );
                }
            }
        }

        wp_enqueue_script('wp-color-picker');
        wp_enqueue_style('wp-color-picker');
    }

    public function display_messages()
    {
        if (!empty($this->errors)) {
            foreach ($this->errors as $error) {
                echo '<div class="notice notice-error is-dismissible"><p>' . esc_html($error) . '</p></div>';
            }
        }

        if (!empty($this->messages)) {
            foreach ($this->messages as $message) {
                echo '<div class="notice notice-success is-dismissible"><p>' . esc_html($message) . '</p></div>';
            }
        }
    }

    public function handle_form_submission()
    {
        if (!isset($_POST['custom_settings_nonce'])) {
            return;
        }

        if (!wp_verify_nonce($_POST['custom_settings_nonce'], 'save_custom_settings')) {
            $this->errors[] = '不正なリクエストです。';
            return;
        }

        if (!current_user_can('manage_options')) {
            $this->errors[] = '権限がありません。';
            return;
        }

        $this->save_settings();

        if (empty($this->errors)) {
            $this->messages[] = '設定を保存しました。';
        }
    }

    private function save_settings()
    {
        $settings_map = array(
            'company_name' => 'text',
            'company_tel' => 'text',
            'company_zip' => 'text', 
            'company_address' => 'text',
            'company_building' => 'text',
            'company_opening' => 'text',
            'company_closed' => 'text',
            'company_map' => 'google_map',
            'main_color' => 'color',
            'base_color' => 'color',
            'contrast_color' => 'color',
            'primary_contrast_color' => 'color',
            'secondary_color' => 'color',
            'secondary_contrast_color' => 'color',
            'tertiary_color' => 'color',
            'tertiary_contrast_color' => 'color',
            'accent_color' => 'color',
            'base_border_color' => 'color',
            'header_logo' => 'image',
            'footer_logo' => 'image',
            'header_logo_width_pc' => 'logo_size',
            'header_logo_width_sp' => 'logo_size',
            'footer_logo_width_pc' => 'logo_size',
            'footer_logo_width_sp' => 'logo_size',
            'gtm_head_code' => 'gtm_code',
            'gtm_body_code' => 'gtm_code',
            'analytics_head_code' => 'analytics_code',
            'analytics_footer_code' => 'analytics_code',
            'custom_css' => 'custom_css',
            'custom_js' => 'custom_js',
            'copyright_text' => 'text',
            'sns_bg_image' => 'image',
            'sns_icon' => 'image',
            'sns_name' => 'text',
            'sns_post' => 'text',
            'sns_description' => 'textarea',
            'facebook_url' => 'sns_url',
            'twitter_url' => 'sns_url',
            'instagram_url' => 'sns_url',
            'youtube_url' => 'sns_url',
            'line_url' => 'sns_url',
            'button_color_1' => 'color',
            'button_text_color_1' => 'color',
            'button_color_2' => 'color',
            'button_text_color_2' => 'color',
            'border_color_2' => 'color',
            'primary_color' => 'color',
            'no_image' => 'image',
            'google_font_base' => 'google_font',
            'google_font_en' => 'google_font',
            'font_mode' => 'text',
            'custom_google_font_link' => 'font_link',
            'custom_adobe_font_link' => 'font_link',
            'custom_font_base' => 'custom_font',
            'custom_font_en' => 'custom_font',
            'custom_font_other1' => 'custom_font',
            'custom_font_other2' => 'custom_font'
        );

        foreach ($settings_map as $field => $type) {
            if (isset($_POST[$field])) {
                $validated_value = $this->validate_field($_POST[$field], $type);
                if ($validated_value !== false) {
                    $db_key = $field;
                    if (in_array($field, ['header_logo', 'footer_logo', 'sns_bg_image', 'sns_icon', 'no_image'])) {
                        $db_key = $field . '_id';
                    }
                    $this->database->update_setting($db_key, $validated_value);
                }
            }
        }

        if (isset($_POST['company_repeater_title']) && isset($_POST['company_repeater_text'])) {
            $repeater_values = $this->validator->validate_repeater_fields(
                $_POST['company_repeater_title'], 
                $_POST['company_repeater_text']
            );
            $this->database->update_setting('company_repeater', serialize($repeater_values));
        }

        if (isset($_POST['custom_settings_nonce'])) {
            $sns_icons = isset($_POST['sns_repeater_icon']) ? $_POST['sns_repeater_icon'] : array();
            $sns_titles = isset($_POST['sns_repeater_title']) ? $_POST['sns_repeater_title'] : array();
            $sns_urls = isset($_POST['sns_repeater_url']) ? $_POST['sns_repeater_url'] : array();
            $sns_repeater_values = $this->validator->validate_sns_repeater_fields($sns_icons, $sns_titles, $sns_urls);
            $this->database->update_setting('sns_repeater', serialize($sns_repeater_values));
        }

        $this->errors = array_merge($this->errors, $this->validator->get_errors());
    }

    private function validate_field($value, $type)
    {
        switch ($type) {
            case 'text':
                return $this->validator->validate_text_field($value);
            case 'textarea':
                return sanitize_textarea_field($value);
            case 'color':
                return $this->validator->validate_hex_color($value);
            case 'image':
                return $this->validator->validate_image_field($value);
            case 'logo_size':
                return $this->validator->validate_logo_size_field($value);
            case 'google_map':
                return $this->validator->validate_google_map_iframe($value);
            case 'sns_url':
                return $this->validator->validate_sns_url($value);
            case 'google_font':
                return $this->validator->validate_google_font($value);
            case 'gtm_code':
                return $this->validator->validate_tracking_code($value, 'gtm');
            case 'analytics_code':
                return $this->validator->validate_tracking_code($value, 'analytics');
            case 'custom_css':
                return $this->validator->validate_custom_css($value);
            case 'custom_js':
                return $this->validator->validate_custom_js($value);
            case 'font_link':
                return $this->validator->validate_font_link($value);
            case 'custom_font':
                return $this->validator->validate_custom_font($value);
            default:
                return sanitize_text_field($value);
        }
    }

    public function render_settings_page()
    {
        if (!current_user_can('manage_options')) {
            wp_die(__('このページにアクセスする権限がありません。'));
        }

        $settings = $this->get_all_settings();
        extract($settings);

        if (!is_array($company_repeater_values)) {
            $company_repeater_values = array();
        }

        if (!is_array($sns_repeater_values)) {
            $sns_repeater_values = array();
        }

        include_once plugin_dir_path(dirname(__FILE__)) . 'templates/admin-settings.php';
    }

    private function get_all_settings()
    {
        return array(
            'company_name' => $this->database->get_setting('company_name'),
            'company_tel' => $this->database->get_setting('company_tel'),
            'company_zip' => $this->database->get_setting('company_zip'),
            'company_address' => $this->database->get_setting('company_address'),
            'company_building' => $this->database->get_setting('company_building'),
            'company_opening' => $this->database->get_setting('company_opening'),
            'company_closed' => $this->database->get_setting('company_closed'),
            'company_map' => $this->database->get_setting('company_map'),
            'company_repeater_values' => $this->database->get_setting('company_repeater'),
            'main_color' => $this->database->get_setting('main_color'),
            'base_color' => $this->database->get_setting('base_color'),
            'contrast_color' => $this->database->get_setting('contrast_color'),
            'primary_contrast_color' => $this->database->get_setting('primary_contrast_color'),
            'secondary_color' => $this->database->get_setting('secondary_color'),
            'secondary_contrast_color' => $this->database->get_setting('secondary_contrast_color'),
            'tertiary_color' => $this->database->get_setting('tertiary_color'),
            'tertiary_contrast_color' => $this->database->get_setting('tertiary_contrast_color'),
            'accent_color' => $this->database->get_setting('accent_color'),
            'base_border_color' => $this->database->get_setting('base_border_color'),
            'header_logo_value' => $this->database->get_setting('header_logo_id'),
            'footer_logo_value' => $this->database->get_setting('footer_logo_id'),
            'header_logo_width_pc' => $this->database->get_setting('header_logo_width_pc'),
            'header_logo_width_sp' => $this->database->get_setting('header_logo_width_sp'),
            'footer_logo_width_pc' => $this->database->get_setting('footer_logo_width_pc'),
            'footer_logo_width_sp' => $this->database->get_setting('footer_logo_width_sp'),
            'gtm_head_code' => $this->database->get_setting('gtm_head_code'),
            'gtm_body_code' => $this->database->get_setting('gtm_body_code'),
            'analytics_head_code' => $this->database->get_setting('analytics_head_code'),
            'analytics_footer_code' => $this->database->get_setting('analytics_footer_code'),
            'custom_css' => $this->database->get_setting('custom_css'),
            'custom_js' => $this->database->get_setting('custom_js'),
            'copyright_text' => $this->database->get_setting('copyright_text'),
            'sns_bg_image_value' => $this->database->get_setting('sns_bg_image_id'),
            'sns_icon_value' => $this->database->get_setting('sns_icon_id'),
            'sns_name' => $this->database->get_setting('sns_name'),
            'sns_post' => $this->database->get_setting('sns_post'),
            'sns_description' => $this->database->get_setting('sns_description'),
            'sns_repeater_values' => $this->database->get_setting('sns_repeater'),
            'facebook_url' => $this->database->get_setting('facebook_url'),
            'twitter_url' => $this->database->get_setting('twitter_url'),
            'instagram_url' => $this->database->get_setting('instagram_url'),
            'youtube_url' => $this->database->get_setting('youtube_url'),
            'line_url' => $this->database->get_setting('line_url'),
            'button_color_1' => $this->database->get_setting('button_color_1'),
            'button_text_color_1' => $this->database->get_setting('button_text_color_1'),
            'button_color_2' => $this->database->get_setting('button_color_2'),
            'button_text_color_2' => $this->database->get_setting('button_text_color_2'),
            'border_color_2' => $this->database->get_setting('border_color_2'),
            'primary_color' => $this->database->get_setting('primary_color'),
            'no_image_value' => $this->database->get_setting('no_image_id'),
            'google_font_base' => $this->database->get_setting('google_font_base'),
            'google_font_en' => $this->database->get_setting('google_font_en'),
            'font_mode' => $this->database->get_setting('font_mode', 'normal'),
            'custom_google_font_link' => $this->database->get_setting('custom_google_font_link'),
            'custom_adobe_font_link' => $this->database->get_setting('custom_adobe_font_link'),
            'custom_font_base' => $this->database->get_setting('custom_font_base'),
            'custom_font_en' => $this->database->get_setting('custom_font_en'),
            'custom_font_other1' => $this->database->get_setting('custom_font_other1'),
            'custom_font_other2' => $this->database->get_setting('custom_font_other2')
        );
    }
}