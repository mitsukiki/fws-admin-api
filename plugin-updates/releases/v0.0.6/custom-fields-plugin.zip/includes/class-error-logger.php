<?php

if (!defined('ABSPATH')) {
    exit;
}

class CustomSettingsErrorLogger
{
    private static $instance = null;
    private $log_file;

    public static function get_instance()
    {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct()
    {
        $upload_dir = wp_upload_dir();
        $this->log_file = $upload_dir['basedir'] . '/custom-settings-errors.log';
    }

    public function log_error($message, $context = array())
    {
        if (!WP_DEBUG || !WP_DEBUG_LOG) {
            return;
        }

        $timestamp = current_time('Y-m-d H:i:s');
        $user_id = get_current_user_id();
        $user_info = $user_id ? "User ID: $user_id" : "No user";
        
        $context_string = !empty($context) ? json_encode($context) : '';
        
        $log_entry = sprintf(
            "[%s] %s | %s | %s\n",
            $timestamp,
            $message,
            $user_info,
            $context_string
        );

        $this->write_to_log($log_entry);
    }

    public function log_validation_error($field, $error_message, $value = null)
    {
        $context = array(
            'field' => $field,
            'value' => $value !== null ? substr(print_r($value, true), 0, 100) : null,
            'type' => 'validation_error'
        );
        
        $this->log_error("Validation failed for field: $field - $error_message", $context);
    }

    public function log_database_error($operation, $table, $error_message)
    {
        $context = array(
            'operation' => $operation,
            'table' => $table,
            'type' => 'database_error'
        );
        
        $this->log_error("Database error during $operation on $table: $error_message", $context);
    }

    public function log_security_event($event_type, $description, $user_capability = null)
    {
        $context = array(
            'event_type' => $event_type,
            'user_capability' => $user_capability,
            'ip_address' => $this->get_user_ip(),
            'type' => 'security_event'
        );
        
        $this->log_error("Security event - $event_type: $description", $context);
    }

    private function write_to_log($message)
    {
        if (!is_writable(dirname($this->log_file))) {
            return false;
        }

        $max_size = 5 * 1024 * 1024; // 5MB
        if (file_exists($this->log_file) && filesize($this->log_file) > $max_size) {
            $this->rotate_log();
        }

        return file_put_contents($this->log_file, $message, FILE_APPEND | LOCK_EX);
    }

    private function rotate_log()
    {
        if (file_exists($this->log_file)) {
            $backup_file = $this->log_file . '.backup';
            if (file_exists($backup_file)) {
                unlink($backup_file);
            }
            rename($this->log_file, $backup_file);
        }
    }

    private function get_user_ip()
    {
        $ip_keys = array('HTTP_CLIENT_IP', 'HTTP_X_FORWARDED_FOR', 'REMOTE_ADDR');
        
        foreach ($ip_keys as $key) {
            if (array_key_exists($key, $_SERVER) === true) {
                $ip = $_SERVER[$key];
                if (strpos($ip, ',') !== false) {
                    $ip = explode(',', $ip)[0];
                }
                $ip = trim($ip);
                if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE)) {
                    return $ip;
                }
            }
        }
        
        return 'unknown';
    }

    public function get_recent_logs($limit = 100)
    {
        if (!current_user_can('manage_options') || !file_exists($this->log_file)) {
            return array();
        }

        $lines = file($this->log_file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        if ($lines === false) {
            return array();
        }

        return array_slice(array_reverse($lines), 0, $limit);
    }

    public function clear_logs()
    {
        if (!current_user_can('manage_options')) {
            return false;
        }

        if (file_exists($this->log_file)) {
            return unlink($this->log_file);
        }

        return true;
    }
}