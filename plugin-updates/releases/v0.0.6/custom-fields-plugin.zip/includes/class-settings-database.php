<?php

if (!defined('ABSPATH')) {
    exit;
}

class CustomSettingsDatabase
{
    private $table_name;
    private $db_version = '1.0';
    private $logger;

    public function __construct()
    {
        global $wpdb;
        $this->table_name = $wpdb->prefix . 'custom_settings';
        require_once plugin_dir_path(__FILE__) . 'class-error-logger.php';
        $this->logger = CustomSettingsErrorLogger::get_instance();
    }

    public function get_table_name()
    {
        return $this->table_name;
    }

    public function create_table()
    {
        global $wpdb;

        $charset_collate = $wpdb->get_charset_collate();

        if (strpos($this->table_name, $wpdb->prefix) !== 0) {
            return false;
        }
        
        $sql = "CREATE TABLE IF NOT EXISTS `" . esc_sql($this->table_name) . "` (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            setting_key varchar(191) NOT NULL,
            setting_value longtext,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY setting_key (setting_key)
        ) " . $charset_collate . ";";

        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        return dbDelta($sql);
    }

    public function drop_table()
    {
        global $wpdb;
        
        if (strpos($this->table_name, $wpdb->prefix) === 0) {
            return $wpdb->query("DROP TABLE IF EXISTS `" . esc_sql($this->table_name) . "`");
        }
        
        return false;
    }

    public function get_setting($key)
    {
        global $wpdb;

        $value = $wpdb->get_var(
            $wpdb->prepare(
                "SELECT setting_value FROM {$this->table_name} WHERE setting_key = %s",
                sanitize_key($key)
            )
        );

        if ($key === 'company_repeater' || $key === 'sns_repeater') {
            return $value !== null ? unserialize($value) : array();
        }

        return $value !== null ? $value : '';
    }

    public function update_setting($key, $value)
    {
        if (!current_user_can('manage_options')) {
            $this->logger->log_security_event('unauthorized_access', 'Attempted to update setting without proper permissions', current_user_can('manage_options'));
            return false;
        }
        
        global $wpdb;

        $result = $wpdb->update(
            $this->table_name,
            array('setting_value' => $value),
            array('setting_key' => sanitize_key($key)),
            array('%s'),
            array('%s')
        );

        if ($result === false) {
            $this->logger->log_database_error('update', $this->table_name, $wpdb->last_error);
        }

        return $result !== false;
    }

    public function insert_setting($key, $value)
    {
        global $wpdb;

        return $wpdb->insert(
            $this->table_name,
            array(
                'setting_key' => sanitize_key($key),
                'setting_value' => $value
            ),
            array('%s', '%s')
        );
    }

    public function setting_exists($key)
    {
        global $wpdb;

        $exists = $wpdb->get_var(
            $wpdb->prepare(
                "SELECT COUNT(*) FROM {$this->table_name} WHERE setting_key = %s",
                sanitize_key($key)
            )
        );

        return (bool) $exists;
    }

    public function initialize_default_settings()
    {
        $default_settings = array(
            'company_name' => '',
            'company_tel' => '',
            'company_zip' => '',
            'company_address' => '',
            'company_building' => '',
            'company_opening' => '',
            'company_closed' => '',
            'company_repeater' => serialize(array(
                array(
                    'title' => '',
                    'text' => ''
                )
            )),
            'main_color' => '',
            'base_color' => '',
            'contrast_color' => '',
            'primary_contrast_color' => '',
            'secondary_color' => '',
            'secondary_contrast_color' => '',
            'tertiary_color' => '',
            'tertiary_contrast_color' => '',
            'accent_color' => '',
            'base_border_color' => '',
            'company_map' => '',
            'header_logo_id' => '',
            'footer_logo_id' => '',
            'header_logo_width_pc' => '150px',
            'header_logo_width_sp' => '120px',
            'footer_logo_width_pc' => '120px',
            'footer_logo_width_sp' => '100px',
            'gtm_head_code' => '',
            'gtm_body_code' => '',
            'analytics_head_code' => '',
            'analytics_footer_code' => '',
            'custom_css' => '',
            'custom_js' => '',
            'copyright_text' => '',
            'sns_bg_image_id' => '',
            'sns_icon_id' => '',
            'sns_name' => '',
            'sns_post' => '',
            'sns_description' => '',
            'sns_repeater' => serialize(array(
                array(
                    'icon_id' => '',
                    'title' => '',
                    'url' => ''
                )
            )),
            'facebook_url' => '',
            'twitter_url' => '',
            'instagram_url' => '',
            'youtube_url' => '',
            'line_url' => '',
            'button_color_1' => '',
            'button_text_color_1' => '',
            'button_color_2' => '',
            'button_text_color_2' => '',
            'border_color_2' => '',
            'primary_color' => '',
            'no_image_id' => '',
            'google_font_base' => '',
            'google_font_en' => '',
            'font_mode' => 'normal',
            'custom_google_font_link' => '',
            'custom_adobe_font_link' => '',
            'custom_font_base' => '',
            'custom_font_en' => '',
            'custom_font_other1' => '',
            'custom_font_other2' => ''
        );

        foreach ($default_settings as $key => $value) {
            if (!$this->setting_exists($key)) {
                $this->insert_setting($key, $value);
            }
        }

        add_option('custom_settings_db_version', $this->db_version);
    }

    public function clean_up()
    {
        delete_option('custom_settings_db_version');
    }

    public function get_all_settings()
    {
        global $wpdb;

        $results = $wpdb->get_results(
            "SELECT setting_key, setting_value FROM {$this->table_name}",
            ARRAY_A
        );

        $settings = array();
        foreach ($results as $row) {
            $key = $row['setting_key'];
            $value = $row['setting_value'];
            
            if ($key === 'company_repeater' || $key === 'sns_repeater') {
                $value = unserialize($value);
            }
            
            $settings[$key] = $value;
        }

        return $settings;
    }

    public function batch_update_settings($settings)
    {
        if (!current_user_can('manage_options')) {
            return false;
        }

        global $wpdb;
        
        $wpdb->query('START TRANSACTION');
        
        try {
            foreach ($settings as $key => $value) {
                $result = $this->update_setting($key, $value);
                if ($result === false) {
                    throw new Exception("Failed to update setting: $key");
                }
            }
            
            $wpdb->query('COMMIT');
            return true;
        } catch (Exception $e) {
            $wpdb->query('ROLLBACK');
            return false;
        }
    }

    public static function get_setting_for_frontend($field_type, $allow_frontend = true)
    {
        if (!$allow_frontend && !is_admin()) {
            $restricted_fields = array(
                'gtm_head_code',
                'gtm_body_code',
                'analytics_head_code',
                'analytics_footer_code',
                'custom_css',
                'custom_js'
            );
            
            if (in_array($field_type, $restricted_fields)) {
                return '';
            }
        }
        
        if (is_admin() && !current_user_can('manage_options')) {
            return '';
        }
        
        global $wpdb;
        $table_name = $wpdb->prefix . 'custom_settings';

        $value = $wpdb->get_var(
            $wpdb->prepare(
                "SELECT setting_value FROM {$table_name} WHERE setting_key = %s",
                sanitize_key($field_type)
            )
        );

        if ($field_type === 'company_repeater' && $value !== null) {
            $repeater_data = unserialize($value);
            if (is_array($repeater_data)) {
                foreach ($repeater_data as &$item) {
                    if (isset($item['text'])) {
                        $item['text'] = wpautop(htmlspecialchars_decode($item['text']));
                    }
                }
            }
            return $repeater_data;
        }

        if ($field_type === 'sns_repeater' && $value !== null) {
            return unserialize($value);
        }

        return $value !== null ? $value : '';
    }
}