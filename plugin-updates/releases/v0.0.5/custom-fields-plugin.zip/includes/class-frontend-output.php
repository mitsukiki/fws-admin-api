<?php

if (!defined('ABSPATH')) {
    exit;
}

class CustomSettingsFrontendOutput
{
    public function __construct()
    {
        add_action('wp_head', array($this, 'output_gtm_head'), 1);
        add_action('wp_body_open', array($this, 'output_gtm_body'), 1);
        add_action('wp_head', array($this, 'output_analytics_head'), 2);
        add_action('wp_footer', array($this, 'output_analytics_footer'), 1);
        add_action('wp_head', array($this, 'output_custom_css'), 100);
        add_action('wp_footer', array($this, 'output_custom_js'), 100);
        add_action('wp_head', array($this, 'output_google_fonts'), 1);
        add_action('wp_head', array($this, 'output_css_variables'), 20);
        add_action('admin_head', array($this, 'output_css_variables'), 20);
    }

    public function output_gtm_head()
    {
        $gtm_head_code = CustomSettingsDatabase::get_setting_for_frontend('gtm_head_code', true);
        if (!empty($gtm_head_code)) {
            echo stripslashes_deep($gtm_head_code);
        }
    }

    public function output_gtm_body()
    {
        $gtm_body_code = CustomSettingsDatabase::get_setting_for_frontend('gtm_body_code', true);
        if (!empty($gtm_body_code)) {
            echo stripslashes_deep($gtm_body_code);
        }
    }

    public function output_analytics_head()
    {
        $analytics_head_code = CustomSettingsDatabase::get_setting_for_frontend('analytics_head_code', true);
        if (!empty($analytics_head_code)) {
            echo stripslashes_deep($analytics_head_code);
        }
    }

    public function output_analytics_footer()
    {
        $analytics_footer_code = CustomSettingsDatabase::get_setting_for_frontend('analytics_footer_code', true);
        if (!empty($analytics_footer_code)) {
            echo stripslashes_deep($analytics_footer_code);
        }
    }

    public function output_custom_css()
    {
        $custom_css = CustomSettingsDatabase::get_setting_for_frontend('custom_css', true);
        if (!empty($custom_css)) {
            echo '<style id="custom-css">' . "\n";
            echo wp_strip_all_tags($custom_css) . "\n";
            echo '</style>' . "\n";
        }
    }

    public function output_custom_js()
    {
        $custom_js = CustomSettingsDatabase::get_setting_for_frontend('custom_js', true);
        if (!empty($custom_js)) {
            $custom_js = stripslashes_deep($custom_js);
            echo '<script id="custom-js">' . "\n";
            echo wp_strip_all_tags($custom_js) . "\n";
            echo '</script>' . "\n";
        }
    }

    public function output_google_fonts()
    {
        $base_font = CustomSettingsDatabase::get_setting_for_frontend('google_font_base', true);
        $en_font = CustomSettingsDatabase::get_setting_for_frontend('google_font_en', true);
        
        $fonts_to_load = array();
        $all_weights = array('300', '400', '500', '600', '700', '800', '900');
        
        if (!empty($base_font)) {
            $fonts_to_load[$base_font] = $all_weights;
        }
        
        if (!empty($en_font) && $en_font !== $base_font) {
            $fonts_to_load[$en_font] = $all_weights;
        }
        
        if (!empty($fonts_to_load)) {
            $google_fonts_url = 'https://fonts.googleapis.com/css2?';
            $family_params = array();
            
            foreach ($fonts_to_load as $font_name => $weights) {
                $family_param = 'family=' . urlencode($font_name) . ':wght@' . implode(';', $weights);
                $family_params[] = $family_param;
            }
            
            $google_fonts_url .= implode('&', $family_params) . '&display=swap';
            
            echo '<link rel="preconnect" href="https://fonts.googleapis.com">' . "\n";
            echo '<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>' . "\n";
            echo '<link href="' . esc_url($google_fonts_url) . '" rel="stylesheet">' . "\n";
        }
    }

    public function output_css_variables()
    {
        $color_settings = array(
            '--primary-color' => CustomSettingsDatabase::get_setting_for_frontend('primary_color', true) ?: '#333',
            '--main-color' => CustomSettingsDatabase::get_setting_for_frontend('main_color', true) ?: '#333',
            '--primary-contrast-color' => CustomSettingsDatabase::get_setting_for_frontend('primary_contrast_color', true) ?: '#fff',
            '--base-color' => CustomSettingsDatabase::get_setting_for_frontend('base_color', true) ?: '#fff',
            '--contrast-color' => CustomSettingsDatabase::get_setting_for_frontend('contrast_color', true) ?: '#333',
            '--secondary-color' => CustomSettingsDatabase::get_setting_for_frontend('secondary_color', true) ?: '#fff',
            '--secondary-contrast-color' => CustomSettingsDatabase::get_setting_for_frontend('secondary_contrast_color', true) ?: '#333',
            '--tertiary-color' => CustomSettingsDatabase::get_setting_for_frontend('tertiary_color', true) ?: '#3F3F3F',
            '--tertiary-contrast-color' => CustomSettingsDatabase::get_setting_for_frontend('tertiary_contrast_color', true) ?: '#fff',
            '--accent-color' => CustomSettingsDatabase::get_setting_for_frontend('accent_color', true) ?: '#eeee22',
            '--base-border-color' => CustomSettingsDatabase::get_setting_for_frontend('base_border_color', true) ?: '#DFDFDF',
            '--button-color-1' => CustomSettingsDatabase::get_setting_for_frontend('button_color_1', true) ?: '#333',
            '--button-text-color-1' => CustomSettingsDatabase::get_setting_for_frontend('button_text_color_1', true) ?: '#fff',
            '--button-color-2' => CustomSettingsDatabase::get_setting_for_frontend('button_color_2', true) ?: '#50575e',
            '--button-text-color-2' => CustomSettingsDatabase::get_setting_for_frontend('button_text_color_2', true) ?: '#fff',
            '--border-color-2' => CustomSettingsDatabase::get_setting_for_frontend('border_color_2', true) ?: '#ddd'
        );
        
        $base_font = CustomSettingsDatabase::get_setting_for_frontend('google_font_base', true);
        $en_font = CustomSettingsDatabase::get_setting_for_frontend('google_font_en', true);
        
        $font_settings = array();
        
        if (!empty($base_font)) {
            $font_settings['--base-font-family'] = '"' . esc_attr($base_font) . '", sans-serif';
        }
        
        if (!empty($en_font)) {
            $font_settings['--en-font-family'] = '"' . esc_attr($en_font) . '", sans-serif';
        } else if (!empty($base_font)) {
            $font_settings['--en-font-family'] = '"' . esc_attr($base_font) . '", sans-serif';
        }

        $all_settings = array_merge($color_settings, $font_settings);
        
        $css_vars = array();
        foreach ($all_settings as $var_name => $value) {
            if (!empty($value)) {
                $css_vars[] = $var_name . ': ' . $value . ';';
            }
        }

        if (!empty($css_vars)) {
            echo '<style id="custom-css-variables">';
            echo ':root {';
            echo implode(' ', $css_vars);
            echo '}';
            echo '</style>' . "\n";
        }
    }
}