<?php

if (!defined('ABSPATH')) {
    exit;
}

class CustomSettingsPlugin
{
    private static $instance = null;
    private $database;
    private $validator;
    private $admin_interface;
    private $frontend_output;

    public static function get_instance()
    {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct()
    {
        $this->init();
        $this->setup_hooks();
    }

    private function init()
    {
        require_once plugin_dir_path(__FILE__) . 'class-settings-validator.php';
        require_once plugin_dir_path(__FILE__) . 'class-settings-database.php';
        require_once plugin_dir_path(__FILE__) . 'class-admin-interface.php';
        require_once plugin_dir_path(__FILE__) . 'class-frontend-output.php';

        $this->database = new CustomSettingsDatabase();
        $this->validator = new CustomSettingsValidator();
        
        if (is_admin()) {
            $this->admin_interface = new CustomSettingsAdminInterface($this->validator, $this->database);
        }
        
        $this->frontend_output = new CustomSettingsFrontendOutput();
    }

    private function setup_hooks()
    {
        register_activation_hook(plugin_dir_path(dirname(__FILE__)) . 'custom-fields-plugin.php', array($this, 'activate_plugin'));
        register_deactivation_hook(plugin_dir_path(dirname(__FILE__)) . 'custom-fields-plugin.php', array($this, 'deactivate_plugin'));
        register_uninstall_hook(plugin_dir_path(dirname(__FILE__)) . 'custom-fields-plugin.php', array(__CLASS__, 'uninstall_plugin'));
    }

    public function activate_plugin()
    {
        $this->database->create_table();
        $this->database->initialize_default_settings();
    }

    public function deactivate_plugin()
    {
        $this->database->clean_up();
    }

    public static function uninstall_plugin()
    {
        $database = new CustomSettingsDatabase();
        $database->drop_table();
        $database->clean_up();
    }

    public static function get_setting($field_type, $allow_frontend = true)
    {
        return CustomSettingsDatabase::get_setting_for_frontend($field_type, $allow_frontend);
    }

    public function get_database()
    {
        return $this->database;
    }

    public function get_validator()
    {
        return $this->validator;
    }
}