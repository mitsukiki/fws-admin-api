<?php

if (!defined('ABSPATH')) {
    exit;
}

require_once plugin_dir_path(__FILE__) . 'class-error-logger.php';

class CustomPluginUpdater
{
    private $plugin_file;
    private $plugin_slug;
    private $version;
    private $update_server_url;
    private $logger;

    public function __construct($plugin_file)
    {
        $this->plugin_file = $plugin_file;
        $this->plugin_slug = plugin_basename($plugin_file);
        $this->version = $this->get_plugin_version();
        $this->update_server_url = 'https://freewebstyles.com/api/plugin-updates/';
        $this->logger = CustomSettingsErrorLogger::get_instance();

        $this->logger->log_error('Plugin updater initialized', [
            'plugin_slug' => $this->plugin_slug,
            'current_version' => $this->version,
            'update_server_url' => $this->update_server_url
        ]);

        add_filter('pre_set_site_transient_update_plugins', array($this, 'check_for_updates'));
        add_filter('plugins_api', array($this, 'plugin_api_call'), 10, 3);
    }

    private function get_plugin_version()
    {
        $plugin_data = get_plugin_data($this->plugin_file);
        return $plugin_data['Version'];
    }

    public function check_for_updates($transient)
    {
        if (empty($transient->checked)) {
            $this->logger->log_error('Update check skipped - no checked plugins');
            return $transient;
        }

        $this->logger->log_error('Checking for plugin updates', [
            'current_version' => $this->version
        ]);

        $remote_version = $this->get_remote_version();
        
        if (version_compare($this->version, $remote_version, '<')) {
            $this->logger->log_error('Update available', [
                'current_version' => $this->version,
                'remote_version' => $remote_version
            ]);

            $transient->response[$this->plugin_slug] = (object) array(
                'slug' => dirname($this->plugin_slug),
                'plugin' => $this->plugin_slug,
                'new_version' => $remote_version,
                'url' => $this->update_server_url,
                'package' => $this->get_download_url($remote_version)
            );
        } else {
            $this->logger->log_error('Plugin is up to date', [
                'current_version' => $this->version,
                'remote_version' => $remote_version
            ]);
        }

        return $transient;
    }

    private function get_remote_version()
    {
        $url = $this->update_server_url . 'check-version.php?slug=' . dirname($this->plugin_slug);
        
        $this->logger->log_error('Requesting remote version', [
            'url' => $url
        ]);

        $request = wp_remote_get($url);
        
        if (is_wp_error($request)) {
            $this->logger->log_error('Failed to get remote version - WP Error', [
                'error_message' => $request->get_error_message(),
                'error_code' => $request->get_error_code()
            ]);
            return $this->version;
        }

        $response_code = wp_remote_retrieve_response_code($request);
        
        if ($response_code !== 200) {
            $this->logger->log_error('Failed to get remote version - HTTP Error', [
                'response_code' => $response_code,
                'response_body' => wp_remote_retrieve_body($request)
            ]);
            return $this->version;
        }

        $body = wp_remote_retrieve_body($request);
        $data = json_decode($body, true);
        
        if (json_last_error() !== JSON_ERROR_NONE) {
            $this->logger->log_error('Failed to parse remote version response', [
                'json_error' => json_last_error_msg(),
                'response_body' => $body
            ]);
            return $this->version;
        }

        $remote_version = isset($data['version']) ? $data['version'] : $this->version;
        
        $this->logger->log_error('Remote version retrieved successfully', [
            'remote_version' => $remote_version,
            'response_data' => $data
        ]);

        return $remote_version;
    }

    private function get_download_url($version)
    {
        return $this->update_server_url . 'download.php?slug=' . dirname($this->plugin_slug) . '&version=' . $version;
    }

    public function plugin_api_call($result, $action, $args)
    {
        if ($action !== 'plugin_information' || $args->slug !== dirname($this->plugin_slug)) {
            return $result;
        }

        $this->logger->log_error('Plugin API call requested', [
            'action' => $action,
            'slug' => $args->slug
        ]);

        $remote_info = $this->get_remote_info();
        
        if ($remote_info) {
            $this->logger->log_error('Plugin information retrieved successfully', [
                'plugin_name' => $remote_info['name'],
                'version' => $remote_info['version']
            ]);

            return (object) array(
                'name' => $remote_info['name'],
                'slug' => $args->slug,
                'version' => $remote_info['version'],
                'author' => $remote_info['author'],
                'homepage' => $remote_info['homepage'],
                'requires' => $remote_info['requires'],
                'tested' => $remote_info['tested'],
                'downloaded' => $remote_info['downloaded'],
                'last_updated' => $remote_info['last_updated'],
                'sections' => array(
                    'description' => $remote_info['description'],
                    'changelog' => $remote_info['changelog']
                ),
                'download_link' => $this->get_download_url($remote_info['version'])
            );
        }

        $this->logger->log_error('Failed to retrieve plugin information');
        return $result;
    }

    private function get_remote_info()
    {
        $url = $this->update_server_url . 'info.php?slug=' . dirname($this->plugin_slug);
        
        $this->logger->log_error('Requesting remote plugin info', [
            'url' => $url
        ]);

        $request = wp_remote_get($url);
        
        if (is_wp_error($request)) {
            $this->logger->log_error('Failed to get remote info - WP Error', [
                'error_message' => $request->get_error_message(),
                'error_code' => $request->get_error_code()
            ]);
            return false;
        }

        $response_code = wp_remote_retrieve_response_code($request);
        
        if ($response_code !== 200) {
            $this->logger->log_error('Failed to get remote info - HTTP Error', [
                'response_code' => $response_code,
                'response_body' => wp_remote_retrieve_body($request)
            ]);
            return false;
        }

        $body = wp_remote_retrieve_body($request);
        $data = json_decode($body, true);
        
        if (json_last_error() !== JSON_ERROR_NONE) {
            $this->logger->log_error('Failed to parse remote info response', [
                'json_error' => json_last_error_msg(),
                'response_body' => $body
            ]);
            return false;
        }

        $this->logger->log_error('Remote plugin info retrieved successfully', [
            'plugin_name' => isset($data['name']) ? $data['name'] : 'unknown',
            'version' => isset($data['version']) ? $data['version'] : 'unknown'
        ]);

        return $data;
    }
}