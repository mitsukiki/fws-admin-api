<?php

if (!defined('ABSPATH')) {
    exit;
}

class CustomSettingsValidator
{
    private $errors = array();
    private $logger;

    public function __construct()
    {
        $this->errors = array();
        require_once plugin_dir_path(__FILE__) . 'class-error-logger.php';
        $this->logger = CustomSettingsErrorLogger::get_instance();
    }

    public function get_errors()
    {
        return $this->errors;
    }

    public function has_errors()
    {
        return !empty($this->errors);
    }

    public function validate_text_field($value, $max_length = 100, $required = false)
    {
        $sanitized_value = sanitize_text_field($value);

        if ($required && empty($sanitized_value)) {
            $this->errors[] = 'テキストフィールドは必須です。';
            return false;
        }

        if (mb_strlen($sanitized_value) > $max_length) {
            $this->errors[] = sprintf('テキストフィールドは%d文字以内で入力してください。', $max_length);
            return false;
        }

        return $sanitized_value;
    }

    public function validate_hex_color($value)
    {
        $sanitized_value = sanitize_text_field($value);

        if (empty($sanitized_value)) {
            return '';
        }

        if (!preg_match('/^#[a-fA-F0-9]{6}$/', $sanitized_value)) {
            $error_message = '無効なカラーコードです。';
            $this->errors[] = $error_message;
            $this->logger->log_validation_error('hex_color', $error_message, $sanitized_value);
            return false;
        }

        return $sanitized_value;
    }

    public function validate_image_field($value)
    {
        $image_id = absint($value);

        if ($image_id > 0) {
            $attachment = get_post($image_id);
            if (!$attachment || $attachment->post_type !== 'attachment') {
                $this->errors[] = '無効な画像IDです。';
                return false;
            }

            $mime_type = get_post_mime_type($image_id);
            $allowed_types = array('image/jpeg', 'image/png', 'image/gif');

            if (!in_array($mime_type, $allowed_types)) {
                $this->errors[] = '許可されていない画像形式です。';
                return false;
            }
        }

        return $image_id;
    }

    public function validate_logo_size_field($value)
    {
        $size = absint($value);

        if ($size < 50 || $size > 400) {
            $this->errors[] = 'ロゴサイズは50px～400pxの範囲で指定してください。';
            return false;
        }

        return $size . 'px';
    }

    public function validate_google_map_iframe($value)
    {
        if (empty($value)) {
            return '';
        }

        $iframe = wp_kses(
            $value,
            array(
                'iframe' => array(
                    'src' => true,
                    'width' => true,
                    'height' => true,
                    'style' => true,
                    'loading' => true,
                    'allowfullscreen' => true,
                    'referrerpolicy' => true
                )
            )
        );

        if (strpos($iframe, '<iframe') === false) {
            $this->errors[] = 'iframeタグが含まれていません。';
            return false;
        }

        preg_match('/src=["\']([^"\']+)["\']/i', $iframe, $matches);
        if (empty($matches[1])) {
            $this->errors[] = 'src属性が見つかりません。';
            return false;
        }

        $src = $matches[1];
        $allowed_url_patterns = array(
            'https://www.google.com/maps/embed',
            'https://maps.google.com/maps',
            'https://maps.app.goo.gl'
        );

        $is_valid_url = false;
        foreach ($allowed_url_patterns as $pattern) {
            if (strpos($src, $pattern) === 0) {
                $is_valid_url = true;
                break;
            }
        }

        if (!$is_valid_url) {
            $this->errors[] = '無効なGoogleマップのURLです。';
            return false;
        }

        $clean_iframe = sprintf(
            '<iframe src="%s" width="%s" height="%s" style="border:0;" loading="lazy" referrerpolicy="no-referrer-when-downgrade" allowfullscreen></iframe>',
            esc_url($src),
            '600',
            '450'
        );

        return $clean_iframe;
    }

    public function validate_sns_url($value)
    {
        if (empty($value)) {
            return '';
        }

        $sanitized_url = esc_url_raw($value);
        
        if (empty($sanitized_url)) {
            $this->errors[] = 'SNS URLの形式が正しくありません。';
            return false;
        }

        if (!filter_var($sanitized_url, FILTER_VALIDATE_URL)) {
            $this->errors[] = '有効なURLを入力してください。';
            return false;
        }

        if (!preg_match('/^https?:\/\//', $sanitized_url)) {
            $this->errors[] = 'URLはhttp://またはhttps://で始まる必要があります。';
            return false;
        }

        return $sanitized_url;
    }

    public function validate_google_font($value)
    {
        if (empty($value)) {
            return '';
        }

        $allowed_fonts = array(
            'Noto Sans JP',
            'Sawarabi Gothic', 
            'M PLUS 1p',
            'Kosugi Maru',
            'Zen Kaku Gothic New',
            'Zen Maru Gothic',
            'Shippori Mincho',
            'Roboto',
            'Open Sans',
            'Lato',
            'Playfair Display',
            'Montserrat',
            'Oswald',
            'Poppins',
            'Inter',
            'Source Sans Pro',
            'Raleway',
            'Nunito',
            'Work Sans'
        );

        $sanitized_font = sanitize_text_field($value);
        
        if (!in_array($sanitized_font, $allowed_fonts)) {
            $this->errors[] = '無効なフォントが選択されました。';
            return false;
        }

        return $sanitized_font;
    }

    public function validate_tracking_code($value, $code_type = 'gtm')
    {
        if (empty($value)) {
            return '';
        }

        $value = stripslashes_deep($value);

        $allowed_html = array(
            'script' => array(
                'src' => true,
                'async' => true,
                'type' => true,
                'defer' => true,
                'id' => true,
                'class' => true
            ),
            'noscript' => array(),
            'iframe' => array(
                'src' => true,
                'height' => true,
                'width' => true,
                'style' => true,
                'frameborder' => true
            ),
            'img' => array(
                'src' => true,
                'alt' => true,
                'width' => true,
                'height' => true,
                'style' => true
            )
        );

        $sanitized_value = wp_kses($value, $allowed_html);

        if (empty($sanitized_value) || strlen($sanitized_value) < 10) {
            if ($code_type === 'gtm' && strpos($value, '<script') !== false && 
                (strpos($value, 'googletagmanager.com') !== false || 
                 strpos($value, 'gtag') !== false || 
                 strpos($value, 'gtm') !== false)) {
                
                $dangerous_patterns = ['javascript:', 'eval(', 'document.write', 'alert(', 'prompt(', 'confirm('];
                $is_safe = true;

                foreach ($dangerous_patterns as $pattern) {
                    if (strpos($value, $pattern) !== false && strpos($value, 'googletagmanager.com') === false) {
                        $is_safe = false;
                        break;
                    }
                }

                if ($is_safe) {
                    return $value;
                }
            }

            $this->errors[] = sprintf('%sコードの形式が正しくありません。', $code_type === 'gtm' ? 'GTM' : 'アクセス解析');
            return false;
        }

        if (strpos($sanitized_value, '<script') === false && strpos($sanitized_value, '<iframe') === false && strpos($sanitized_value, '<img') === false) {
            $this->errors[] = sprintf('%sコードには有効なHTMLタグが含まれている必要があります。', $code_type === 'gtm' ? 'GTM' : 'アクセス解析');
            return false;
        }

        return $sanitized_value;
    }

    public function validate_custom_css($value)
    {
        if (empty($value)) {
            return '';
        }

        $value = stripslashes_deep($value);
        $sanitized_value = wp_strip_all_tags($value);
        
        if (mb_strlen($sanitized_value) > 10000) {
            $this->errors[] = 'カスタムCSSは10000文字以内で入力してください。';
            return false;
        }

        return $sanitized_value;
    }

    public function validate_custom_js($value)
    {
        if (empty($value)) {
            return '';
        }

        $value = stripslashes_deep($value);
        $sanitized_value = wp_strip_all_tags($value);
        
        if (mb_strlen($sanitized_value) > 10000) {
            $this->errors[] = 'カスタムJavaScriptは10000文字以内で入力してください。';
            return false;
        }

        return $sanitized_value;
    }

    public function validate_repeater_fields($titles, $texts)
    {
        if (!is_array($titles) || !is_array($texts)) {
            return array();
        }

        $sanitized_values = array();
        $max_entries = min(count($titles), count($texts));

        for ($i = 0; $i < $max_entries; $i++) {
            $sanitized_title = sanitize_text_field($titles[$i]);

            $allowed_html = wp_kses_allowed_html('post');
            $allowed_html['iframe'] = array(
                'src' => true,
                'width' => true,
                'height' => true,
                'style' => true,
                'frameborder' => true,
                'allowfullscreen' => true,
                'loading' => true,
                'class' => true,
                'title' => true,
                'referrerpolicy' => true,
                'id' => true
            );

            $sanitized_text = wp_kses($texts[$i], $allowed_html);

            if (empty($sanitized_title) && empty($sanitized_text)) {
                continue;
            }

            if (mb_strlen($sanitized_title) > 100) {
                $this->errors[] = sprintf('繰り返しフィールドの %d 番目のタイトルは100文字以内で入力してください。', $i + 1);
                $sanitized_title = mb_substr($sanitized_title, 0, 100);
            }

            if (mb_strlen(strip_tags($sanitized_text)) > 1000) {
                $this->errors[] = sprintf('繰り返しフィールドの %d 番目のテキストは1000文字以内で入力してください。', $i + 1);
            }

            $sanitized_values[] = array(
                'title' => $sanitized_title,
                'text' => $sanitized_text
            );
        }

        if (count($sanitized_values) > 10) {
            $this->errors[] = '繰り返しフィールドは最大10個までです。';
            return array_slice($sanitized_values, 0, 10);
        }

        return $sanitized_values;
    }

    public function validate_sns_repeater_fields($icons, $titles, $urls)
    {
        if (!is_array($icons) || !is_array($titles) || !is_array($urls)) {
            return array();
        }

        $sanitized_values = array();
        $max_entries = min(count($icons), count($titles), count($urls));

        for ($i = 0; $i < $max_entries; $i++) {
            $sanitized_icon_id = absint($icons[$i]);
            $sanitized_title = sanitize_text_field($titles[$i]);
            $sanitized_url = esc_url_raw($urls[$i]);

            if (empty($sanitized_icon_id) && empty($sanitized_title) && empty($sanitized_url)) {
                continue;
            }

            if ($sanitized_icon_id > 0) {
                $attachment = get_post($sanitized_icon_id);
                if (!$attachment || $attachment->post_type !== 'attachment') {
                    $this->errors[] = sprintf('SNSリピーター %d 番目の画像IDが無効です。', $i + 1);
                    $sanitized_icon_id = 0;
                }
            }

            if (mb_strlen($sanitized_title) > 100) {
                $this->errors[] = sprintf('SNSリピーター %d 番目のタイトルは100文字以内で入力してください。', $i + 1);
                $sanitized_title = mb_substr($sanitized_title, 0, 100);
            }

            if (!empty($sanitized_url) && !filter_var($sanitized_url, FILTER_VALIDATE_URL)) {
                $this->errors[] = sprintf('SNSリピーター %d 番目のURLが無効です。', $i + 1);
                $sanitized_url = '';
            }

            $sanitized_values[] = array(
                'icon_id' => $sanitized_icon_id,
                'title' => $sanitized_title,
                'url' => $sanitized_url
            );
        }

        if (count($sanitized_values) > 10) {
            $this->errors[] = 'SNSリピーターは最大10個までです。';
            return array_slice($sanitized_values, 0, 10);
        }

        return $sanitized_values;
    }
}