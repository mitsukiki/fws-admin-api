<?php

/**
 * Plugin Name: Custom Settings Plugin
 * Description: 管理画面にテーマ設定を追加するプラグイン
 * Version: 0.0.2
 * Author: Your Name
 * Update URI: https://freewebstyles.com/api/plugin-updates/custom-settings-plugin
 * Requires at least: 5.0
 * Tested up to: 6.4
 * Requires PHP: 7.4
 */

if (!defined('ABSPATH')) {
    exit;
}

define('WP_ENV', 'product'); // 開発環境の場合は 'development'、本番環境では 'production' に変更

require_once plugin_dir_path(__FILE__) . 'includes/class-custom-settings-plugin.php';
require_once plugin_dir_path(__FILE__) . 'includes/class-plugin-updater.php';

function init_custom_settings_plugin()
{
    CustomSettingsPlugin::get_instance();
    
    // アップデーター初期化
    if (is_admin()) {
        new CustomPluginUpdater(__FILE__);
    }
}

add_action('plugins_loaded', 'init_custom_settings_plugin');