<?php

/**
 * Plugin Name: Custom Settings Plugin
 * Description: 管理画面にテーマ設定を追加するプラグイン
 * Version: 0.0.4
 * Author: Your Name
 * Update URI: https://freewebstyles.com/api/plugin-updates/custom-settings-plugin
 * Requires at least: 5.0
 * Tested up to: 6.4
 * Requires PHP: 7.4
 */

if (!defined('ABSPATH')) {
    exit;
}

// .envファイルから環境変数を読み込み
$env_file = plugin_dir_path(__FILE__) . '.env';
if (file_exists($env_file)) {
    $env_vars = parse_ini_file($env_file);
    if (isset($env_vars['WP_ENV'])) {
        define('WP_ENV', $env_vars['WP_ENV']);
    } else {
        define('WP_ENV', 'production'); // デフォルト値
    }
} else {
    define('WP_ENV', 'production'); // .envファイルがない場合のデフォルト値
}

require_once plugin_dir_path(__FILE__) . 'includes/class-custom-settings-plugin.php';
require_once plugin_dir_path(__FILE__) . 'includes/class-plugin-updater.php';

function init_custom_settings_plugin()
{
    CustomSettingsPlugin::get_instance();
    
    // アップデーター初期化
    if (is_admin()) {
        new CustomPluginUpdater(__FILE__);
    }
}

add_action('plugins_loaded', 'init_custom_settings_plugin');